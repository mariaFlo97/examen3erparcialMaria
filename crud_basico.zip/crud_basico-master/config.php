<?php
$mysqli = new mysqli('localhost', 'root', '', 'crud_basico');
?>